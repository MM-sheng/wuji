# WUJI: first scheduled checkpoint replay

This supplemental evidence pack is separate from r4; it does not modify the contract, the pinned r4 fixture or the published GitHub repo. It is a project-side replay and is not an outside review, audit, proof of user demand or recommendation to use real funds.

## What to verify

- Bitcoin checkpoint height: **973865**
- Checkpoint block hash: `0000000000000000000153f4e6fa27cdc12f20a54492a6e86389daaaa1424fab`
- Cumulative signed integer: **U = 8341**
- Sepolia value: **S = 0.100092** (`S_wad = 100092000000000000`)
- Sepolia observation block: [12178068](https://sepolia.etherscan.io/block/12178068), hash `0x4f9244d91b1f5b6aaf34db637884892bae631a472e1b3c8d1a0267e01ec77082`
- [Header-v3 contract](https://sepolia.etherscan.io/address/0x4a70Ebc03DA98f04d88964E17dF212ba1bb2705a). The observation block is not claimed to be the block that first recorded the checkpoint.

## Offline replay

Unzip and run with Python 3.9+:

```sh
python3 replay.py --full
python3 replay.py
```

The full command reconstructs the raw 80-byte Bitcoin headers from public block metadata from 967680 through 973965. It verifies continuity, proof of work, median time, difficulty changes, the deployment anchor, the archived r4 prefix digest and historical continuity, and includes 100 headers beyond the checkpoint. It initializes the index to zero at deployment, not to r4's accumulated value. The shorter command starts from the pinned r4 continuity at height 972510 and checks the subsequent 1455 headers. Both compare with the checkpoint value in the pinned Sepolia evidence. No wallet or network is required for offline replay. This is header validation, not validation of Bitcoin transactions or full blocks.

You can also fetch your own page evidence: in a second copy of the scripts, omit the bundled `pages/` and run `python3 fetch_public.py` (add `--incremental` for the shorter range), then replay it. Metadata may include changing explorer statistics; compare reconstructed header digests rather than raw page JSON. This can take several minutes. The fetcher stops on a failed response rather than retrying automatically. Use `python3 replay.py --full --headers PATH` to supply consecutive 80-byte headers from another source instead.

## Check on-chain state independently

```sh
node verify_chain.mjs https://sepolia.gateway.tenderly.co
```

This uses Node.js and curl, reads only, and checks chain ID, pinned block hash, finality, runtime bytecode digest, relay height and checkpoint flag/value. An RPC without retained state can return a history error; use a provider that serves the observation block. Do not shorten the pinned height to latest silently. You can also calculate the Bitcoin result using your own Bitcoin Core node and verify the resulting header digest against the offline receipt.

## Evidence sources

- Bitcoin metadata: `https://mempool.space/api/v1/blocks/{height}`; each included page contains 15 descending blocks.
- Checkpoint header cross-check: `https://blockstream.info/api/block/0000000000000000000153f4e6fa27cdc12f20a54492a6e86389daaaa1424fab/header`.
- Baseline: [r4 pinned candidate](https://github.com/MM-sheng/wuji/blob/e884e05a42fb72d91ca8cc996efe1da7fe2c7ffc/verification/header-v3/candidate.json).
- Rule: for each finalized header from genesis, add the sum of bytes in SHA-256 of the raw double-SHA-256 hash minus 4080. Multiply the cumulative integer by 12000000000000 for the Solidity-scaled value.
