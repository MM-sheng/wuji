#!/usr/bin/env python3
"""Download public Bitcoin metadata into an empty or resumable local evidence directory."""
import argparse, json, pathlib, subprocess, time

BASE='https://mempool.space/api/v1/blocks/'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--incremental',action='store_true')
parser.add_argument('--out',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent/'pages')
args=parser.parse_args()
args.out.mkdir(parents=True,exist_ok=True)
for i,h in enumerate(range(973965,972510 if args.incremental else 967679,-15),1):
    fn=args.out/f'{h}.json'
    if fn.exists(): continue
    response=subprocess.run(['curl','--silent','--show-error','--max-time','30','--write-out','\n%{http_code}',BASE+str(h)],capture_output=True)
    body,_,status=response.stdout.rpartition(b'\n')
    if response.returncode or status!=b'200':
        raise SystemExit(f'Fetch stopped at {h} (HTTP {status.decode(errors="replace")}); existing pages preserved. Follow the provider\'s cooldown rule before resuming.')
    rows=json.loads(body)
    if [r['height'] for r in rows]!=list(range(h,h-15,-1)): raise SystemExit(f'Unexpected page layout at {h}')
    with fn.open('xb') as f: f.write(body)
    if i%25==0: print(f'Fetched Bitcoin metadata through height {h-14}.',flush=True)
    time.sleep(1)
