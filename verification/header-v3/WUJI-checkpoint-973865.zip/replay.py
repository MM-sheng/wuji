#!/usr/bin/env python3
"""Recompute the WUJI first checkpoint using Bitcoin header data, without RPC."""
import argparse, hashlib, json, pathlib, struct

P=pathlib.Path(__file__).resolve().parent
C=json.loads((P/'r4-candidate.json').read_text())
END=973865
LIMIT=(1<<224)-1
def require(ok,msg):
    if not ok: raise ValueError(msg)
def sha(b): return hashlib.sha256(b).digest()
def compact(v):
    size=(v.bit_length()+7)//8
    m=(v << (8*(3-size))) if size<=3 else (v >> (8*(size-3)))
    if m&0x800000: size+=1;m>>=8
    return size<<24|m
def target(bits):
    size,m=bits>>24,bits&0x7fffff
    v=(m >> (8*(3-size))) if size<=3 else (m << (8*(size-3)))
    require(not bits&0x800000 and 0<v<=LIMIT, 'invalid compact target')
    return v
def get_headers(first, last):
    by_height={}
    for h in range(last,first-1,-15):
        fn=P/'pages'/f'{h}.json'
        rows=json.loads(fn.read_text())
        require(len(rows)==15 and [r['height'] for r in rows]==list(range(h,h-15,-1)),f'page layout {h}')
        for r in rows:
            if r['height']<first: continue
            b=struct.pack('<I',r['version']&0xffffffff)+bytes.fromhex(r['previousblockhash'])[::-1]+bytes.fromhex(r['merkle_root'])[::-1]+struct.pack('<III',r['timestamp'],r['bits'],r['nonce'])
            require(len(b)==80 and sha(sha(b))[::-1].hex()==r['id'],f"header reconstruction {r['height']}")
            by_height[r['height']]=b
    return b''.join(by_height[h] for h in range(first,last+1))
def main(full, raw_file=None):
    old=C['expected']['continuity']
    a=C['anchor']
    last=END+C['confirmations']
    first=a['epochFirst'] if full else old['height']+1
    headers=raw_file.read_bytes() if raw_file else get_headers(first,last)
    require(len(headers)==(last-first+1)*80, "wrong raw header length")
    prev=None if full else bytes.fromhex(old['hash'][2:])
    times=[] if full else old['times'].copy()
    bits=None if full else old['bits']
    previous_ts=None if full else old['time']
    epoch=a['epochStart'] if full else old['epochStart']
    total=0 if full else int(old['u'])
    work=int(C['anchorWork']) if full else int(old['work'])
    chain=json.loads((P/'sepolia.json').read_text())
    expected=int(chain['checkpoint_S_wad'])
    unit=int(C['unit'])
    require(END==a['genesisHeight']-1+C['checkpointInterval'],'first scheduled height')
    if full:
        require(first%2016==0 and struct.unpack_from('<I',headers,68)[0]==a['epochStart'],'anchor epoch start')
        lo=C['expected']['spanFrom']; hi=C['expected']['spanTo']
        require(sha(headers[(lo-first)*80:(hi-first+1)*80]).hex()==C['expected']['spanSha256'],'r4 prefix checksum')
    checkpoint=None
    for h in range(first,last+1):
        b=headers[(h-first)*80:(h-first+1)*80]; digest=sha(sha(b))
        version=struct.unpack_from('<i',b)[0]; ts,n_bits=struct.unpack_from('<II',b,68)
        require(version>=4,f'version {h}')
        require(ts<=int(chain['block_timestamp'])+7200,f'future time {h}')
        if prev is not None:
            require(b[4:36]==prev,f'link {h}')
            if h%2016==0:
                span=max(302400,min(4838400,previous_ts-epoch))
                require(n_bits==compact(min(LIMIT,(target(bits)*span)//1209600)),f'retarget {h}')
                epoch=ts
            else:
                require(n_bits==bits,f'difficulty {h}')
        if len(times)==11: require(ts>sorted(times)[5],f'median time {h}')
        times=(times+[ts])[-11:]
        require(int.from_bytes(digest,'little')<=target(n_bits),f'proof of work {h}')
        if full and h==a['anchorHeight']:
            require(b.hex()==a['anchorHeader'][2:] and times==a['ancestorTimes'],'anchor bytes and timestamps')
        if h>=a['genesisHeight']:
            total+=sum(sha(digest))-C['mean']
            require(-(1<<63)<=total<(1<<63),f'int64 U {h}')
            work+=(1<<256)//(target(n_bits)+1)
        if full and h==old['height']:
            require((digest.hex(),n_bits,ts,epoch,total,times,work)==(old['hash'][2:],old['bits'],old['time'],old['epochStart'],int(old['u']),old['times'],int(old['work'])),'r4 continuity')
        if h==END:
            reference=P/"blockstream-header.txt"
            if reference.exists(): require(b.hex()==reference.read_text().strip(),"Blockstream checkpoint header mismatch")
            checkpoint={'btc_height':h,'btc_hash':digest[::-1].hex(),'U':total,'S_wad':str(total*unit)}
        prev,bits,previous_ts=digest,n_bits,ts
    require(int(checkpoint['S_wad'])==expected, 'Sepolia checkpoint differs')
    print(json.dumps({'status':'PASS_FULL_CHECKPOINT_REPLAY' if full else 'PASS_INCREMENTAL_CHECKPOINT_REPLAY','range':[first,last],'headers':(last-first+1),'headers_sha256':sha(headers).hex(),'confirmation_headers':C['confirmations'],'checkpoint':checkpoint},indent=2))
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full',action='store_true',help='Replay from the difficulty epoch containing the deployment anchor')
    parser.add_argument("--headers",type=pathlib.Path,help="Optional file with consecutive raw 80-byte headers in ascending height order")
    args=parser.parse_args()
    main(args.full,args.headers)
